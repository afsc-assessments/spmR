# Publication reference — historical snapshot, 2026-10-28

The repository and deployment observations below record the original preparation. They are historical evidence; this presentation revision does not verify a new public deployment.

The original local run completed at 00:23:26 UTC and the original report rendered at 00:27:52 UTC on October 28. The status investigation at 01:25–01:26 UTC found the published website predated them. Jim subsequently confirmed his local 47-value SSB history is authoritative for this example and explicitly authorized its repository publication with the matching fully worked example/results.

- Public repository: <https://github.com/afsc-assessments/spmR>
- Local and public `main`: `d6bdbf10de6deeb59a8a73e08e6e465ee677ddae`; local work includes uncommitted input/report/documentation changes.
- Latest pkgdown success: <https://github.com/afsc-assessments/spmR/actions/runs/40594471452>
- Latest Pages success: <https://github.com/afsc-assessments/spmR/actions/runs/40594898435>, completed October 27 at 22:27:37 UTC.
- Live audit article: <https://afsc-assessments.github.io/spmR/articles/gt2026_inputs.html> — HTTP 200; still describes 47 recruitment and 45 SSB values, generates no projection results and contains no figures.
- <https://afsc-assessments.github.io/spmR/examples/gt_2026/greenland_turbot.html> — HTTP 404.
- <https://afsc-assessments.github.io/spmR/articles/greenland_turbot.html> — HTTP 404.

Fresh direct HTTP requests were used, not web-search cache. The result HTML and run output are ignored locally, and the standalone result report is not among the website's registered articles. Simply pushing the QMD would not publish the ignored rendered results.

## Input revision and publication destination

`spm.dat` and `tacpar.dat` match the already-public examples exactly. The bundled local `ForProjections.dat` has **47 SSB entries**, while public `main` has **45**. Its only numerical change repeats the final existing SSB pair; this still changes the supplied historical series and derived calculations. PR #37 preserves the 45-value history blocker, and PR #38 is styling only. Neither clears the local 47/47 revision.

The earlier clearance gap is resolved by Jim's confirmation: **the local 47-value SSB revision belongs in the repository**. Its source file is preserved byte-for-byte. Calendar pairing, source definitions and population-weight assumptions remain scientific review items; publication does not convert the diagnostic output into adopted catch advice.

The scoped publication uses tracked pkgdown static assets linked from the GT2026 article. The revised HTML embeds two Alternative 2 plots; standalone PNGs are also supplied for reuse. Use these reference links after the normal repository Pages deployment:

- Report: <https://afsc-assessments.github.io/spmR/greenland_turbot.html>
- Complete fully worked example ZIP: <https://afsc-assessments.github.io/spmR/gt2026-handoff.zip>
- SSB figure: <https://afsc-assessments.github.io/spmR/gt2026-figures/SSB.png>
- Catch figure: <https://afsc-assessments.github.io/spmR/gt2026-figures/Catch.png>

See the final delivery message for verified live deployment status. No email is sent by this workflow.
