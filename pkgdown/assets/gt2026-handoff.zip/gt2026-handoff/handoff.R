# Greenland turbot: read saved results, edit inputs, stage/run, plot and tabulate.
# First install spmR 0.4.3 (see REQUIREMENTS.md). No model runs on source().
handoff_files <- c(
  vapply(sys.frames(), function(x) if (is.null(x$ofile)) "" else x$ofile[1], ""),
  sub("^--file=", "", grep("^--file=", commandArgs(FALSE), value = TRUE)))
handoff_files <- handoff_files[basename(handoff_files) == "handoff.R" & file.exists(handoff_files)]
handoff_root <- if (length(handoff_files)) dirname(normalizePath(tail(handoff_files, 1))) else getwd()
if (!requireNamespace("spmR", quietly = TRUE) || utils::packageVersion("spmR") < "0.4.3") {
  stop("Install spmR 0.4.3 first; see REQUIREMENTS.md.", call. = FALSE)
}
input_dir <- file.path(handoff_root, "examples", "gt_2026")
saved_run <- file.path(input_dir, "spmR_runs", "attempt-001")
source(file.path(input_dir, "run.R"))
source(file.path(input_dir, "report.R"))

# Editing: change values in examples/gt_2026/ForProjections.dat, preserving its
# headings/order, or replace all three input files with a consistent export.
# This adapter supports this two-sex, two-fleet, 30-age, beginning-of-2026 layout.
check_inputs <- function() {
  audit <- check_gt2026_inputs(input_dir)
  print(as.data.frame(audit), row.names = FALSE)
  invisible(audit)
}

# Use a NEW run directory each time; the helper protects old attempts.
# To use verified population weights, pass both sex-specific vectors, units
# and ages. diagnostic=TRUE explicitly selects the documented proxy weights.
run_current <- function(diagnostic = FALSE, population_weights = NULL,
                        units = NULL, ages = NULL, execute = TRUE,
                        executable = Sys.getenv("SPMR_EXECUTABLE", "")) {
  raw <- gt2026_read_source(input_dir)
  month_row <- grep("# Spawning month$", trimws(raw$lines))
  if (length(month_row) != 1L || !identical(raw$numbers(month_row), 1)) {
    stop("This handoff requires spawning month 1; other months need revised initial-SSB validation.")
  }
  projection <- run_gt2026_projection(source_dir = input_dir, diagnostic = diagnostic,
    population_weights = population_weights, units = units, ages = ages,
    executable = executable, run = execute)
  if (!is.null(projection$result)) {
    provenance <- jsonlite::read_json(file.path(projection$run_dir,
      "spm_last_success_provenance.json"), simplifyVector = FALSE)
    attr(projection$result, "handoff_units") <- provenance$species[[1]]$units$biomass
    attr(projection$result, "handoff_weights") <- if (is.null(population_weights)) "diagnostic proxies" else "caller supplied"
  }
  invisible(projection)
}

# Validate saved hashes/provenance before reading; never starts a projection.
read_results <- function(run_dir = saved_run) {
  saved <- gt2026_read_report_run(run_dir, input_dir)
  if (!all(saved$source_comparison$matches_current)) {
    warning("Saved results use older inputs. Run again to evaluate edited inputs.", call. = FALSE)
  }
  result <- saved$result
  attr(result, "handoff_units") <- saved$biomass_units
  attr(result, "handoff_weights") <- saved$decisions$population_weights
  result
}

# All simulations contribute to the mean, median and 5th/95th percentiles.
useful_table <- function(result, years = sort(unique(result$Year)),
                         alts = sort(unique(result$Alt))) {
  result |>
    dplyr::filter(.data$Year %in% .env$years, .data$Alt %in% .env$alts) |>
    dplyr::group_by(.data$Alt, .data$Year) |>
    dplyr::summarise(dplyr::across(
      dplyr::all_of(c("SSB", "Tot_biom", "Catch", "ABC", "OFL")),
      list(mean = mean, median = stats::median,
           p05 = ~unname(stats::quantile(.x, 0.05)),
           p95 = ~unname(stats::quantile(.x, 0.95)))), .groups = "drop")
}

# Choose metric: SSB, Tot_biom, Catch, ABC or OFL. Grey band = 90% interval;
# thin blue lines = first 15 simulations; black = all-simulation median.
plot_results <- function(result, metric = "SSB", alts = c(1, 3, 5, 7)) {
  stopifnot(metric %in% c("SSB", "Tot_biom", "Catch", "ABC", "OFL"))
  unit <- attr(result, "handoff_units")
  if (is.null(unit)) unit <- "declared biomass units"
  weights <- attr(result, "handoff_weights")
  if (is.null(weights)) weights <- "see run provenance"
  result <- dplyr::filter(result, .data$Alt %in% .env$alts)
  series <- gt2026_report_series(result, n_worms = 15L)
  bands <- dplyr::filter(series$summary, .data$metric == .env$metric)
  paths <- dplyr::filter(series$worms, .data$metric == .env$metric)
  ggplot2::ggplot(bands, ggplot2::aes(x = .data$Year)) +
    ggplot2::geom_ribbon(ggplot2::aes(ymin = .data$lower, ymax = .data$upper), fill = "grey85") +
    ggplot2::geom_line(data = paths, ggplot2::aes(y = .data$value, group = .data$Sim),
                       colour = "#336A99", alpha = 0.35, linewidth = 0.35) +
    ggplot2::geom_line(ggplot2::aes(y = .data$median), linewidth = 0.65) +
    ggplot2::facet_wrap(ggplot2::vars(Alt), labeller = "label_both", ncol = 2) +
    ggplot2::labs(x = "Projection year", y = paste0(metric, " (", unit, ")"),
      title = "Greenland turbot: conditional projections",
      subtitle = paste("Population weights:", weights, "— source review remains open")) +
    ggplot2::theme_bw(base_size = 11)
}

write_results <- function(result, output_dir = file.path(handoff_root, "output")) {
  dir.create(output_dir, showWarnings = FALSE, recursive = TRUE)
  readr::write_csv(useful_table(result), file.path(output_dir, "annual-summary.csv"))
  first_years <- head(sort(unique(result$Year)), 3)
  readr::write_csv(useful_table(result, years = first_years),
                   file.path(output_dir, "first-three-years.csv"))
  for (metric in c("SSB", "Tot_biom", "Catch", "ABC", "OFL")) {
    ggplot2::ggsave(file.path(output_dir, paste0(metric, ".png")),
      plot_results(result, metric, alts = sort(unique(result$Alt))),
      width = 9, height = 9, dpi = 150)
  }
  message("Wrote CSV tables and five figures to ", output_dir)
  invisible(result)
}

if (sys.nframe() == 0L) {
  args <- commandArgs(trailingOnly = TRUE)
  action <- if (length(args)) args[1] else "saved"
  message("Using spmR ", utils::packageVersion("spmR"))
  if (action == "check") {
    check_inputs()
  } else if (action == "saved") {
    result <- read_results()
    write_results(result)
    print(useful_table(result, years = 2026:2028, alts = c(1, 3, 5, 7)), width = Inf)
  } else if (action %in% c("stage", "run")) {
    if (!"--diagnostic" %in% args) {
      stop("CLI run/stage requires --diagnostic to choose proxy weights explicitly. For verified weights, source handoff.R and call run_current(); see README.md.")
    }
    projection <- run_current(diagnostic = TRUE, execute = action == "run")
    message("New attempt: ", projection$run_dir)
    if (action == "run") write_results(projection$result)
  } else {
    stop("Usage: Rscript handoff.R [saved|check|stage --diagnostic|run --diagnostic]")
  }
}
