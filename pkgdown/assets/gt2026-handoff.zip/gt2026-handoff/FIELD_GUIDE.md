# Greenland turbot input field guide

This guide describes the supplied **2026, two-sex, two-fleet, 30-age** example and spmR **0.4.3**. Row numbers below refer to the bundled source `examples/gt_2026/ForProjections.dat`, before staging. Keep an unchanged source copy and edit a separate copy for a new run.

## Species file: `ForProjections.dat`

The native model reads values in positional order. The GT2026 preparation helper also uses the existing comment headings to locate blocks: retain those headings and the female/male and fleet order. Every age vector below has **30 values in the same age order**.

| Source row(s) | Field | Meaning |
|---|---|---|
| 1 | Stock name | `Greenland_turbot`; a single token. |
| 2 | `SSL_spp` | Legacy SSL prey-control flag; currently 0 (off). |
| 3 | `Const_Buffer` | Constant-buffer option for author ABC; currently 0 (off). |
| 4–5 | `ngear`, `nsexes` | Two fleets, two sexes. This helper expects this layout. |
| 6 | `avg_5yrF` | Average five-year fishing mortality, 0.05605452; used by alternative 3. |
| 7 | `FABC_Adj` | Author F adjustment, 1; used in alternative 2. The source comment says `Author f`. |
| 8–9 | `SPR_abc`, `SPR_ofl` | SPR fractions 0.40 and 0.35. Row 9's `SPR MSY` comment corresponds to the native **OFL SPR** field. |
| 10 | `spawnmo` | Spawning month, 1. The model uses `(month − 1)/12` as the pre-spawning fraction of the year. Keep 1 in this example: other months need revised initial-SSB validation and are rejected before staging. |
| 11 | Recruitment basis | `per sex`. The preparation helper moves this declaration into embedded metadata; it is **not an extra native positional field**. |
| 12 | `nages` | 30 age positions. Diagnostic declarations use ages 1–30; the last position is a plus group. Confirm this against the export. |
| 13 | `Frat` | Fleet F allocation, 0.96 and 0.04; nonnegative fractions summing to 1. These are not population mixing fractions. |
| 15–16 | `M_F`, `M_M` | Annual instantaneous natural mortality by age: female, then male. |
| 18, 20 | `pmature_F`, `pmature_M` | Maturity proportions by age, female then male; currently all 1. |
| 22–23 | `wt_F`, `wt_M` | Spawning-weight vectors, female then male. Row 23 has no separate male heading. |
| 25–26 | `wt_gear_F` | Female catch weights: fleet 1, then fleet 2. |
| 28–29 | `wt_gear_M` | Male catch weights: fleet 1, then fleet 2. |
| 31–32 | `sel_F` | Female selectivity: fleet 1, then fleet 2. Nonnegative relative values; each fleet needs a positive value. |
| 34–35 | `sel_M` | Male selectivity: fleet 1, then fleet 2. |
| 37–38 | `n0_F`, `n0_M` | Beginning-of-projection abundance by age, female then male. Confirm beginning-of-2026 timing. |
| 40 | `nrec` | 47 historical recruitment positions; the native input also requires exactly 47 SSB positions. |
| 42–43 | Recruitment history | Two identical copies of a 47-value **per-sex** series. The helper keeps one copy. The engine doubles that complete series once to total recruitment; do not double it manually as well. |
| 45 | SSB history | 47 positive values. These are historical SSB, not age vectors. |

Comment-only rows separate the blocks. The current two recruitment copies are accepted only because they are identical. One complete copy is also accepted; line wrapping is allowed. Different female and male recruitment histories cannot be represented by retaining two different copies in this format.

## Units and three different kinds of weights

The saved run explicitly declares **thousand fish**, **kg per fish**, and **tonnes**. Thousand fish × kg per fish gives tonnes. These are diagnostic declarations requiring source verification, not units inferred safely from the text file.

Spawning biomass uses female abundance × female maturity × female spawning weight, with spawning-time survival. If the supplied spawning weights already include maturity, applying maturity again would double-count it. The working example retains all-one maturity multipliers; confirm the SS3 export definition before replacing them. Male maturity affects the reported maturity-weighted abundance and female fraction; with all-one fields those describe all fish. Male spawning weights do not add males to female SSB.

Catch weights convert catches at age to catch biomass. **Population body weights** calculate total population biomass and are supplied separately through the runner's female/male arguments and embedded declarations. The saved diagnostic uses `0.96 × fleet 1 catch weight + 0.04 × fleet 2 catch weight`, separately by sex, as population-weight proxies. Actual population weights are still needed for assessment use. The staging helper replaces the four zero spawning weights with `1e-12` to satisfy the current positive-weight contract and records that change; it preserves the source.

## Control file: `spm.dat`

Keep positional order and existing labels. Some labels differ from the native names:

| Control in this example | Current meaning/value |
|---|---|
| Run name; `Tier`; `nalts`; `alts` | Greenland turbot; Tier 3; seven alternatives, 1–7. |
| `tac_flag` → `TAC_ABC` | 1; current format-2 execution supports this setting. |
| `srr_type` → `SrType`; `srr_form` → `Rec_Gen` | 2 (Beverton–Holt curve identifier); **1 (historical recruitment simulation)**, so no stock–recruitment fit is performed. |
| `srr_conditioning`; `srr_reserved` | Native `Fmsy_F35=0` and `Rec_Cond=0`; labels do not change positional meaning. |
| `spm_detail_flag`; `nprj_yrs`; `nsims`; `beg_yr` | Detailed output on; 15 years; 1,000 simulations; start 2026. |
| `nyrs_fixed_catch`; `nspp`; `OY_min/max` | Three prescribed-catch years; one stock; aggregate OY limits 0 and 2,000,000. |
| `datafile`; `ABC_mults`; `scalars` | `ForProjections.dat`; ABC multiplier 1; `N_scalar=1` (required in format 2). |
| `alt4_spr`; `nTAC_cat`; `nTACind` | Alternative-4 SPR fraction 0.75; TAC category count/index both 1. |
| `fixed_catch` | Year/catch pairs: 2026/193.28, 2027/378, 2028/378 tonnes. All three apply to alternatives 1–5; alternatives 6–7 share the first-year catch, then follow their scenario rules. |

`tacpar.dat` is preserved for provenance but **is not read with `TAC_ABC=1`**. Its legacy contents are not a supported tuning interface for this example. Changing that flag is outside the validated GT2026 workflow.

## Replacing inputs and checking a new run

1. Copy the source inputs; preserve the saved attempt and original files. Replace whole vectors from a documented export, preserving sex, fleet, age order and plus group.
2. Supply verified female/male population body weights, units and ages through `run_current()` as described in the example README. Use `--diagnostic` only when deliberately choosing the recorded proxy assumptions. A separate JSON file is not required: spmR 0.4.3 writes validated declarations as comments in the staged species file.
3. Run the example's `check` action, then `stage`; inspect the new directory, archived source, declarations and staging decisions before `run`. Each action creates a fresh attempt from the current source; `run` does not execute the earlier staged directory. Keep sources unchanged after review and compare source hashes in the new attempt. This helper is specific to 2026, spawning month 1, two sexes, two fleets and 30 ages; broader layout or start-year changes require adapting it.
4. Check successful provenance, empty/understood stderr, finite nonnegative output and unique stock/alternative/simulation/year keys. Current settings imply 105,000 rows. Compare initial biomass with abundance × declared population weights and verify prescribed catches. Historical recruitment mode fits no parameters, so gradient/Hessian convergence tests do not apply.

**Unresolved source review:** the current counts match (47/47), but the final SSB pair repeats the preceding pair. The recruitment label spans 1978–2022 (45 years), while the SSB label spans 1978–2026 (49 years). Neither establishes the calendar pairing of 47 positions. Obtain the intended histories and SS3 field definitions; never pad, trim or relabel values merely to make counts agree. Successful execution verifies a conditional calculation, not adopted catch advice.

Checked against the supplied `run.R`, `examples/gt20/run_spmR_split_sex.R`, package `R/spm-inputs.R`, and native `inst/admb/spm.tpl` on 2026-10-28.
