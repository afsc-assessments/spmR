# Greenland turbot handoff

Unzip the whole folder. This is a working example of **spmR 0.4.3**, with the actual input files, one completed run, an editable R script, and a rendered report. Results are conditional diagnostics, not adopted catch advice. Jim confirmed that the local 47-value SSB revision is the intended example input and authorized publishing it with these results.

1. Open `examples/gt_2026/greenland_turbot.html` in a browser. It already contains five figures and tables; no R, Quarto or internet is needed to view it.
2. Install R and spmR using `REQUIREMENTS.md`. Open this folder as your R working directory.
3. Run `source("handoff.R")` and the commands below. Sourcing defines functions and reads no projection output until you request it.

```r
source("handoff.R")
check_inputs()                        # Audit the current three input files
result <- read_results()              # Read and validate the included successful run
plot_results(result, "SSB", alts = c(1, 3, 5, 7))
plot_results(result, "Catch", alts = c(1, 5))
tab <- useful_table(result, years = 2026:2028, alts = c(1, 3, 5, 7))
print(tab, width = Inf)
write.csv(tab, "my-table.csv", row.names = FALSE)
write_results(result)                 # Five PNGs + two CSV tables in output/
```

Use `"Tot_biom"`, `"ABC"` or `"OFL"` for other plots. Tables report mean, median and 5th/95th percentiles using every simulation. Plots show 15 paths plus the all-simulation median and 90% interval. `output/` is regenerated when you call `write_results()`; choose another `output_dir` to preserve a set of exports.

## Change inputs and run

The species file is **`examples/gt_2026/ForProjections.dat`**, with exact spelling and capitalization. `spm.dat` holds run/scenario/catch controls, and `tacpar.dat` is the companion TAC file. Read `FIELD_GUIDE.md` before editing. Keep a copy of the original files; edit the working files, not `spmR_runs/attempt-001/`.

```r
# Edit examples/gt_2026/ForProjections.dat in a plain-text editor, then:
check_inputs()

# Explicitly choose the existing diagnostic weight/units/age assumptions.
# Staging validates/copies inputs without compiling or running the model:
staged <- run_current(diagnostic = TRUE, execute = FALSE)
staged$run_dir

# This starts a NEW native projection, compiling if no compatible binary exists.
projection <- run_current(diagnostic = TRUE)
projection$run_dir
new_result <- read_results(projection$run_dir)
write_results(new_result, output_dir = "my-new-results")
```

For independently verified population body weights, replace the diagnostic call with:

```r
# Define these from the reviewed source export; these names are placeholders.
# Each weight vector has 30 entries in the documented age order.
projection <- run_current(
  population_weights = list(female = female_body_weights, male = male_body_weights),
  units = verified_units, ages = verified_ages
)
```

Use the documented units names, for example `list(abundance="thousand_fish", weight="kg", biomass="t")`, only when verified for the export. Each new call creates a separate attempt. Existing attempts are never overwritten. A staged-only attempt has no results; use the directory returned by a completed run when reading output.

The helper is specific to two sexes, two fleets, 30 ages, spawning month 1, Tier 3 historical recruitment and the beginning-of-2026 controls. It is not a general SS3 importer. Replacing exports that change these dimensions, spawning month or start year requires adapting and reviewing the helper, rather than rearranging vectors until it runs. `stage` and `run` each create a fresh attempt from the current source files; `run` does not execute the earlier staged directory. Keep sources unchanged after review and compare the new source hashes.

Equivalent terminal commands, from this folder:

```sh
Rscript handoff.R check
Rscript handoff.R saved
Rscript handoff.R stage --diagnostic
Rscript handoff.R run --diagnostic
```

## What is included

- `FIELD_GUIDE.md`: what each input block means and what must stay aligned.
- `REQUIREMENTS.md`: installation and toolchain requirements.
- `handoff.R`: the short entry script for checking, running, plotting and tables.
- `examples/gt_2026/`: actual current inputs, preserved runner/report helpers, report source and self-contained HTML.
- `examples/gt_2026/spmR_runs/attempt-001/`: completed output, original source snapshots, hashes and provenance. Platform-specific executable omitted; see requirements for new runs.
- `examples/gt20/run_spmR_split_sex.R`: sibling utility required by the runner; retain both directories.
- `output/`: example PNGs and CSVs made from the saved run by `handoff.R`.
- `VALIDATION.md` and `MANIFEST.sha256`: test record and file checksums.

The included raw input is the local revision with 47 recruitment and 47 SSB entries. The final SSB pair repeats the preceding pair and calendar labels remain unresolved. Actual population body weights are absent; the saved run uses sex-specific fleet-weight proxies. Source definitions, units/ages/plus group and recruitment/SSB calendar pairing still need review. Matching counts and successful execution do not resolve these issues.

To re-render the editable report with Quarto, keep the folder layout and run:

```sh
quarto render examples/gt_2026/greenland_turbot.qmd
```

The QMD currently selects the included `attempt-001`. To show a different completed attempt, pass `-P saved_run:spmR_runs/attempt-002`, replacing the directory name with the actual returned attempt. Rendering reads saved results; the manual model-run chunk is excluded. For audit-only rendering, set `saved_run: ""` in the copied QMD. See `REQUIREMENTS.md` for optional rendering dependencies.
