# Fully worked example verification

## Historical verification — 2026-10-28

The checks below describe the earlier five-figure bundle. They are retained as historical evidence, not results of the current presentation revision.

This is a computational fully worked example, not an accepted assessment or a catch recommendation. No biological inputs or scientific assumptions were changed while preparing it. Jim confirmed that his local 47-value SSB revision is the intended repository input and authorized publication. The actual local input revision, existing successful output and runner/report helpers were copied; only the new entry script, instructions and a clearer report-control sentence were added.

## What was tested

- Runner guard correction (example revision 3): the repository GT2026 runner now rejects spawning months other than 1 before staging or execution, matching the existing portable entry-script guard. Its independent initial-SSB calculation assumes beginning-of-year spawning. The focused GT2026 suite passes 195 assertions with zero failures, warnings or skips, including source preservation and no attempt creation on rejection. Supplied inputs, saved attempt evidence and pre-rendered results are unchanged.

- Render-default correction (example revision 2): reproduced the plain-command failure in a source-only copy with no `spmR_runs` directory. The QMD now defaults to an empty saved-run selection. Plain rendering produces an audit with zero projection figures; an explicit saved-run selection produces five figures. The raw inputs, saved outputs, runner, scientific assumptions and `handoff.R` are unchanged. No model rerun was needed.
- Correction regression suite: 191 assertions in 22 GT2026 test cases passed with zero failures, warnings or skips. The added integration case renders the actual source-only QMD, then explicitly selects a synthetic saved attempt; it verifies rendered status/figure counts, unchanged source and saved hashes, and no new attempt directory. Explicit nonexistent saved selections remain hard errors.
- A separate relocated copy, outside the spmR checkout, was exercised with `Rscript --vanilla` and an explicitly selected installed R library. Tested environment: R 4.6.1, spmR 0.4.3, macOS arm64, ggplot2 4.0.3, dplyr 1.2.1, tidyr 1.3.2, readr 2.2.0, jsonlite 2.0.0 and digest 0.6.39.
- All 42 installed spmR runtime functions matched the checkout function definitions; the installed native template SHA-256 matched the checkout template. Package runtime code has no local modifications relative to public `main` commit `d6bdbf10de6deeb59a8a73e08e6e465ee677ddae`.
- Saved-run input/output/source hashes and successful provenance were validated before reading its 105,000 unique rows: seven alternatives × 1,000 simulations × 2026–2040. All recorded 17 output hashes matched.
- The entry script's saved-results, input-check, diagnostic-stage and diagnostic-run commands succeeded. New attempts were created separately; existing output was preserved. One relocated native execution was used as an initial portability check, and a second checked the final entry script after its result-label handling was revised. Each native simulation took about two seconds; the existing compatible local executable was reused rather than recompiling it.
- Fresh detail output reproduced the included saved output byte-for-byte: SHA-256 `929046e937adbf470eaefe467a427a1787ee2959f68f3828cbe3206b02932fdd`.
- Five plot metrics, alternative selection, table year selection, all-simulation means, units and population-weight labels were checked. The SSB figure was visually inspected. The spawning-month guard rejected a changed month before staging; the test source was restored exactly.
- Quarto 1.10.18 successfully re-rendered the copied report with the included saved results. The first attempt completed all R chunks but could not write Quarto's standard cache within the restricted sandbox; the authorized render succeeded with cache access. No model was run by rendering.
- The delivered HTML was checked for five embedded PNG images with alt text, semantic tables, English document language and no external image/script/stylesheet dependency. The delivered PNGs/CSV tables were regenerated with the final script from the included original saved run.
- The originating spmR checkout, input files and saved attempt were preserved. The archive omits the platform-specific executable; recipients compile from the installed current template or provide a compatible native binary.

## Scope and limits

| Gate | Outcome | Evidence or remaining work |
|---|---|---|
| Product/track | Pass | Small fully worked example; no SAFE/asar migration needed. |
| Provenance | Pass | Source snapshots, input/output hashes, successful run provenance, pinned software revision and archive manifest. |
| Computational consistency | Pass | Fresh execution and saved output agree exactly; 105,000 valid unique rows. |
| Scientific acceptance | Not established | Population-weight proxies, SS3 definitions, units/age/plus group, repeated SSB tail and calendar pairing need review. |
| Local render | Pass | Re-rendered copied QMD; five figures embedded; manual execution chunk excluded. |
| HTML accessibility | Partial | Language, alt attributes, tables and representative plot checked. Full contrast, keyboard, screen-reader and agency review not tested; no Section 508 conformance claim. |
| Cross-platform execution | Not tested | macOS arm64 only. Windows/Linux require their own compatible ADMB/C++ toolchain or format-2 binary. |
| Fresh package installation | Not tested | Existing installed 0.4.3 tested and compared with source; pinned installation instructions supplied. Internet/package dependencies are not bundled. |
| Public clearance | Pass | Jim explicitly confirmed the local 47-value SSB history belongs in the repository and authorized the matching example/results publication. Scientific acceptance remains separate. |

TAF-compatible traceability is retained through original source snapshots → staged declarations → native output/provenance → tables/figures → self-contained report → release manifest. No additional workflow framework is required to use this small bundle.


## Earlier two-figure presentation revision — 2026-10-28

The bundle is now named a fully worked example. Its requested result figures are Alternative 2 SSB and catch, with salmon 90% projection ribbons; SSB uses a logarithmic y-axis and dashed B40/B35 reference lines. The entry script delegates plotting to the shared report helper. The SSB and catch exports replace the previous five exported figures; both CSV tables remain available.

Current checks completed in independent R/Quarto processes (R 4.6.1, spmR 0.4.3, Quarto 1.10.18):

- The focused GT2026 report suite passed 82 assertions with zero failures, warnings or skips. Its integration check confirms audit-only rendering has zero projection images and an explicitly selected saved run has two; source files and saved evidence retain their hashes and no attempt is created.
- Both the source report and this portable report rendered successfully with the included saved attempt. The revised vignette rendered successfully. Render and export logs contain no warnings or errors.
- The entry script's saved-results command regenerated two Alternative 2 PNGs and both CSVs successfully. No model was executed during this revision.
- Independent checks of built plot data confirm only Alternative 2, 15 years and all 1,000 simulations per year. Median and 5th/95th percentiles match independent calculations from all 15,000 Alternative 2 rows. The ribbon is salmon; SSB uses log10; both dashed reference lines equal the saved B40 and B35 values.
- The saved reader verified successful native provenance, completion logs and recorded hashes for 105,000 rows. All 30 original input and saved-attempt files in the preceding ZIP match this revision byte-for-byte.
- Both HTML reports contain exactly two embedded PNGs, descriptive alt text, English document language and no external image/script/stylesheet resources. Both figures were extracted from the portable HTML and visually inspected: titles, axes, ribbons and reference labels are readable and unclipped.
- The archive manifest was regenerated and every entry verified after packaging. It excludes the manifest itself. Source and portable report helpers and QMD files match exactly.

Track/provenance/computational consistency/render gates: Pass. Scientific acceptance: unchanged and separate from these presentation checks. HTML accessibility: partial (source/structure and figure visual checks passed; browser layout, keyboard, screen-reader and agency review were not tested). Native compilation and gradient/Hessian diagnostics: not applicable to this presentation revision; no model or fitted recruitment calculation was run. Public deployment was not performed by this revision.


## Current three-figure presentation revision — 2026-10-28

Revision 6 adds projected Alternative 2 F, with a linear year⁻¹ axis and dashed F40/F35 reference lines read from the saved run. SSB and catch use logarithmic y-axes; all three figures use salmon 90% projection ribbons. The portable entry script passes the saved F reference points to the shared plot helper and exports SSB, catch and F PNGs at 9 × 5 inches, plus both CSV summaries with annual-rate F columns.

Current validation:

- All 97 focused GT2026 report assertions passed without failures, warnings or skips. The suite checks three-figure saved rendering, zero-figure audit rendering, hash protection of the reference summary, missing/invalid F values, and saved SPR targets before labelling F40/F35.
- Source and portable reports plus the vignette rendered successfully in independent processes. The entry script regenerated three PNGs and both CSVs; render/export logs contain no warnings or errors.
- Independent calculations from all 15,000 Alternative 2 rows confirm the median and 5th/95th percentile ribbons in all three figures. SSB and catch use log10 y-axes; projected F uses a linear axis and dashed F40 = 0.170193 and F35 = 0.199079 per year. The saved summary supplies F_abc/F_ofl, and the staged SPR targets of 0.40/0.35 establish their F40/F35 labels.
- Both HTML reports contain exactly three embedded PNGs with descriptive alt text, English document language and no external image/script/stylesheet resources. Rendered catch and F figures were extracted and visually inspected. The local report was opened/refreshed in Chrome and its F figure, labels, caption and page layout were checked. The F-axis rate uses plotmath to render the superscript correctly.
- All 30 original input and saved-attempt files match the preceding ZIP byte-for-byte; the saved reader independently verifies provenance and all recorded hashes. Scientific inputs and model code are unchanged. No native model or parameter fit was run.
- All regenerated manifest entries were verified in the packaged ZIP. Root and portable report helpers/QMDs match exactly. Credential and proprietary database-path scans of changed text and bundled scripts passed.

Track, provenance, consistency and render gates: Pass. Scientific acceptance: unchanged. Accessibility: partial; keyboard, screen-reader and agency checks remain untested. Model compilation, gradient and Hessian checks are not applicable to these report changes. Public deployment is verified separately from committing/pushing this revision.
