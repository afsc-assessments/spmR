# Handoff verification — 2026-10-28

This is a computational handoff/working example, not an accepted assessment or a catch recommendation. No biological inputs or scientific assumptions were changed while preparing it. Jim confirmed that his local 47-value SSB revision is the intended repository input and authorized publication. The actual local input revision, existing successful output and runner/report helpers were copied; only the new entry script, instructions and a clearer report-control sentence were added.

## What was tested

- A separate relocated copy, outside the spmR checkout, was exercised with `Rscript --vanilla` and an explicitly selected installed R library. Tested environment: R 4.6.1, spmR 0.4.3, macOS arm64, ggplot2 4.0.3, dplyr 1.2.1, tidyr 1.3.2, readr 2.2.0, jsonlite 2.0.0 and digest 0.6.39.
- All 42 installed spmR runtime functions matched the checkout function definitions; the installed native template SHA-256 matched the checkout template. Package runtime code has no local modifications relative to public `main` commit `d6bdbf10de6deeb59a8a73e08e6e465ee677ddae`.
- Saved-run input/output/source hashes and successful provenance were validated before reading its 105,000 unique rows: seven alternatives × 1,000 simulations × 2026–2040. All recorded 17 output hashes matched.
- The entry script's saved-results, input-check, diagnostic-stage and diagnostic-run commands succeeded. New attempts were created separately; existing output was preserved. One relocated native execution was used as an initial portability check, and a second checked the final entry script after its result-label handling was revised. Each native simulation took about two seconds; the existing compatible local executable was reused rather than recompiling it.
- Fresh detail output reproduced the included saved output byte-for-byte: SHA-256 `929046e937adbf470eaefe467a427a1787ee2959f68f3828cbe3206b02932fdd`.
- Five plot metrics, alternative selection, table year selection, all-simulation means, units and population-weight labels were checked. The SSB figure was visually inspected. The spawning-month guard rejected a changed month before staging; the test source was restored exactly.
- Quarto 1.10.18 successfully re-rendered the copied report with the included saved results. The first attempt completed all R chunks but could not write Quarto's standard cache within the restricted sandbox; the authorized render succeeded with cache access. No model was run by rendering.
- The delivered HTML was checked for five embedded PNG images with alt text, semantic tables, English document language and no external image/script/stylesheet dependency. The delivered PNGs/CSV tables were regenerated with the final script from the included original saved run.
- The originating spmR checkout, input files and saved attempt were preserved. The archive omits the platform-specific executable; recipients compile from the installed current template or provide a compatible native binary.

## Scope and limits

| Gate | Outcome | Evidence or remaining work |
|---|---|---|
| Product/track | Pass | Small working-example handoff; no SAFE/asar migration needed. |
| Provenance | Pass | Source snapshots, input/output hashes, successful run provenance, pinned software revision and archive manifest. |
| Computational consistency | Pass | Fresh execution and saved output agree exactly; 105,000 valid unique rows. |
| Scientific acceptance | Not established | Population-weight proxies, SS3 definitions, units/age/plus group, repeated SSB tail and calendar pairing need review. |
| Local render | Pass | Re-rendered copied QMD; five figures embedded; manual execution chunk excluded. |
| HTML accessibility | Partial | Language, alt attributes, tables and representative plot checked. Full contrast, keyboard, screen-reader and agency review not tested; no Section 508 conformance claim. |
| Cross-platform execution | Not tested | macOS arm64 only. Windows/Linux require their own compatible ADMB/C++ toolchain or format-2 binary. |
| Fresh package installation | Not tested | Existing installed 0.4.3 tested and compared with source; pinned installation instructions supplied. Internet/package dependencies are not bundled. |
| Public clearance | Pass | Jim explicitly confirmed the local 47-value SSB history belongs in the repository and authorized the matching example/results publication. Scientific acceptance remains separate. |

TAF-compatible traceability is retained through original source snapshots → staged declarations → native output/provenance → tables/figures → self-contained report → release manifest. No additional workflow framework is required to use this small bundle.
