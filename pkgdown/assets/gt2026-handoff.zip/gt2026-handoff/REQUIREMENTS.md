# Installation and requirements

## Open the saved results

The included `greenland_turbot.html` is self-contained. Open it in a browser; all three Alternative 2 plots are embedded. R, ADMB and Quarto are not needed to view it.

## Use the R fully worked example

- **R 4.1.0 or newer**, as declared by spmR 0.4.3.
- **spmR 0.4.3**. Its imports include `digest`, `dplyr`, `ggplot2`, `ggthemes`, `jsonlite`, `magrittr`, `patchwork`, `readr`, `stringr`, `tibble` and `tidyr`; install the package with dependencies. The example script uses these imports, with no additional reporting package required.
- Keep the example's directories together, including the sibling `examples/gt20/run_spmR_split_sex.R` helper. Use a writable copy for staged inputs and new results.

Public source: <https://github.com/afsc-assessments/spmR>. The verified public `main` commit at preparation was `d6bdbf10de6deeb59a8a73e08e6e465ee677ddae`, whose package version is 0.4.3. Pin that commit rather than assuming a `v0.4.3` tag exists:

```r
install.packages("remotes")  # only if needed
remotes::install_github(
  "afsc-assessments/spmR",
  ref = "d6bdbf10de6deeb59a8a73e08e6e465ee677ddae",
  build_vignettes = FALSE
)
packageVersion("spmR")  # 0.4.3
```

Restart R after installation so an older loaded namespace/template is not reused. The copied GT2026 helper and report files in this fully worked example include local work newer than that public package commit; retain those supplied copies.

## Execute a new projection

Saved-output reading, input checks and staging do not need ADMB. A new projection needs either a compatible executable for the recipient's operating system/architecture, or:

- **ADMB 13.0 or newer** and a matching C++ toolchain. The repository's native CI pins ADMB **13.2**. Obtain ADMB from its [official releases](https://github.com/admb-project/admb/releases).
- Put `admb` on `PATH`, or set `SPMR_ADMB` to its path. `SPMR_CXX` can select a compiler compatible with the installed ADMB libraries. Windows compiler compatibility matters; the helper can discover a bundled `utilities/mingw/bin/g++.exe` when present.
- Alternatively set `SPMR_EXECUTABLE` to an existing compatible `spm`/`spm.exe`. A binary from another OS/architecture is not portable.

The helper compiles the **installed package's** self-contained `admb/spm.tpl` with `admb -f spm.tpl`. No separate C++ header is needed. A newly compiled current engine should report both lines:

```text
SPMR_INPUT_FORMAT=2
SPMR_INLINE_INPUT=1
```

Probe with `spm -spmr-capabilities` (use the executable's actual path). Never substitute an old legacy binary that lacks format-2 support. New runs require explicit recruitment basis, units, ages and population weights; spmR embeds these declarations in the staged species file. Separate JSON/native sidecars are optional compatibility paths.

## Optional editable Quarto report

To re-render the supplied `greenland_turbot.qmd`, additionally install the **Quarto CLI** and R packages `quarto`, `knitr`, `rmarkdown` and `gt`; retain the neighboring `run.R` and `report.R`. Existing HTML viewing and the portable R script do not require these. Rendering reads a selected saved attempt and does not launch ADMB. No exact Quarto minimum is declared by this example; its saved render log confirms a successful render, not cross-version certification.

The installation requirements above were checked against package `DESCRIPTION`, the native-engine README, GT2020/GT2026 helpers and CI workflow. No new software installation is implied by this fully worked example.
