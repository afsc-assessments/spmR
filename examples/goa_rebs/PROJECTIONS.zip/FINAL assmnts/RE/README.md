README

This model is the author recomended M15.4_2021. Below are the models used in the 2021 assessment for reference.

Model naming conventions:

M15.4_2019 - 2019 assessment model (unchanged since 2015) with 2019 data

M15.4_2021 - 2019 assessment model with 2021 data. Author recommended model. This version uses updated SDs for the LLS RPNs from the 2021 longline survey database update. This version does not use the 2019 trawl survey age comps due to age reader mistake (see notes below).

M15.4b_2021 - 2019 assessment model with 2021 data. This version uses the status quo (M15.4_2019) method to obtain SDs for the LLS RPNs, where the SD is derived from the longterm mean and SD of the RPN time series. This version also does not use the 2019 trawl survey age comps due to age reader mistake (see notes below).

M15.4c_2021 - M15.4_2021 with 2019 trawl survey age comp data.

M15.4d_2021 - M15.4b_2021 with 2019 trawl survey age comp data.